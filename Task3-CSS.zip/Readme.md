# Task 3: CSS Selectors

## Files
- `index.html` – page markup
- `style.css` – all styling (linked via `<link rel="stylesheet" href="style.css">`)

## What was done
1. `index.html` and `style.css` created and linked together.
2. Body background color set (`coral`).
3. Three heading tags (`h1`, `h2`, `h3`) all given `class="head"`.
4. `.head` class selector gives all three headings dark blue text.
5. The `h2` also has `id="bglime"`, which gives it a lime background.
6. The word "head" inside the `h2` is wrapped in a `<span>` and colored red.
7. Three `<p>` tags with no id/class, styled white using the plain `p` element selector.
8. The second paragraph has `id="para"` and is styled green.
9. The word "paragraph" in the third paragraph is wrapped in a `<span>` and made black + larger font-size.
10. Two `<a>` links (no id/class) inside a `<ul>` are styled differently using
    `ul li:nth-of-type(1) a` and `ul li:nth-of-type(2) a` — structural selectors instead of id/class.
11. An `<ol>` with 5 `<li>` items (no id/class) uses `:nth-child(2)` (blue) and `:nth-child(3)` (red)
    to color specific items without adding id/class attributes.

## Notes
- No Bootstrap used — styling is done only with plain CSS selectors (element, id, class, and structural pseudo-classes).
- Tested by opening `index.html` directly in the browser.
